// controllers/taskController.js
const Task = require('../models/Task');

exports.createTask = async (req, res) => {
  try {
    const task = await Task.create({
      ...req.body,
      user: req.user.id
    });
    res.status(201).json(task);
    console.log('📥 Request body:', req.body);
console.log('👤 User:', req.user.id);

  } catch (err) {
    console.error('❌ Failed to create task:', err);
    res.status(500).json({ message: 'Failed to create task' });
  }
};


exports.getTasks = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = 5;
    const skip = (page - 1) * limit;

    const tasks = await Task.find({ user: req.user.id })  // ← Important
      .skip(skip)
      .limit(limit)
      .sort({ createdAt: -1 });

    const totalTasks = await Task.countDocuments({ user: req.user.id });
    const totalPages = Math.max(1,Math.ceil(totalTasks / limit));

    res.json({ tasks, totalPages });
  } catch (err) {
    console.error('Failed to fetch tasks:', err);
    res.status(500).json({ message: 'Server Error' });
  }
};



exports.getTaskById = async (req, res) => {
  try {
    const task = await Task.findOne({
      _id: req.params.id,
      user: req.user.id,
    });

    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    res.json(task);
  } catch (err) {
    console.error('❌ Failed to fetch task by ID:', err);
    res.status(500).json({ message: 'Server Error' });
  }
};

exports.updateTask = async (req, res) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, user: req.user.id });

    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    // Update fields
    task.title = req.body.title || task.title;
    task.description = req.body.description || task.description;
    task.dueDate = req.body.dueDate || task.dueDate;
    task.priority = req.body.priority || task.priority;
    task.status = req.body.status || task.status;

    const updatedTask = await task.save();
    res.json(updatedTask);
  } catch (err) {
    console.error('❌ Failed to update task:', err);
    res.status(500).json({ message: 'Server Error' });
  }
};


exports.deleteTask = async (req, res) => {
  try {
    const task = await Task.findOneAndDelete({
      _id: req.params.id,
      user: req.user.id,
    });

    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    res.json({ message: 'Task deleted' });
  } catch (err) {
    console.error('❌ Error deleting task:', err);
    res.status(500).json({ message: 'Server Error' });
  }
};


exports.changeStatus = async (req, res) => {
  try {
    const task = await Task.findOne({
      _id: req.params.id,
      user: req.user.id,
    });

    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    task.status = req.body.status;
    await task.save();

    res.json({ message: 'Status updated', task });
  } catch (err) {
    console.error('❌ Failed to change status:', err);
    res.status(500).json({ message: 'Server Error' });
  }
};
